
<h1 align="center">
    Web application
    <br>
     <img src="https://img.shields.io/badge/FINPAY PAYMENT GATEWAY-424242?style=flat-square">
</h1>

<p align="center">
    <img src="https://img.shields.io/badge/Python-3.11-bf616a?style=flat" alt="a" />
    <img src="https://img.shields.io/badge/Flask-3.0.0-274fa8?style=flat" alt="b" />
    <img src="https://img.shields.io/badge/Requests-2.31.0-2965ea?style=flat" alt="b" />
</p>

## Install
Use virtual env or not `your choice`

```
pip Install -r requirements.txt
```

## run
```
python3 app.py
```